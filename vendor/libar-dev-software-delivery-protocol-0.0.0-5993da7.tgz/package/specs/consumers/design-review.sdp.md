---
id: spec:consumers.design-review
kind: behavior
altitude: feature
readiness: ready
relations:
  refines: spec:consumers.projections-model
  decidedBy: spec:decisions.shipped-projections-frozen
---
# Design Review renders graph context without becoming a gate

## Intent
- outcome: Give a human a regenerable, contextual view for deciding how to state readiness without recording approval as graph truth.

## Behavior
- rule: Design Review renders a Spec or Pack in context with relations, bindings, delivery badges, design questions, and findings from the graph.
- rule: The review is a pure projection that resolves through ordinary source edits, git, and conformance checks; it stores no findings and writes no canonical source.
- rule: A human may use the review context when stating readiness, while validators check only the structural readiness floor and never record or require review approval.
- rule: The MVP view is deterministic generated Markdown with an index and pages for Specs and Packs; richer visual representations remain outside this behavior.
- rule: The page set is a function of the graph alone — it carries no timestamp, no commit, and no run identity — so two renders of the same corpus are byte-identical.
- rule: Rendering encodes by Markdown syntax context: prose and table fields escape structural characters, fenced JSON preserves authored keys and values through JSON encoding, and inline code uses a delimiter that preserves literal backticks.
- rule: The realizing entrypoint is `renderDesignReview` in `src/projections/design-review.ts`, which reads the reader and returns pages; writing them is the caller's job.

## UI
The generated Design Review exposes three page anatomies from the same graph.

- specPage: A Spec page presents descriptors, readiness, relations, bindings, authored sections, and findings in one context.
- packPage: A Pack page presents framing, model references, and an ordered member table with each member's kind, altitude, readiness, and implementation and verifier bindings.
- indexPage: The index presents one sortable-style Markdown table for Specs and a linked bullet list for Packs, with stable links into their detail pages.

## Example space
```gwt-vocabulary
Given an extraction root holding a Pack, its member Specs, and one member the checks warn about
When the Design Review renders the graph derived from that root
Then the page set holds the index page {indexPage:string}, one page per Spec, and one page per Pack
Then the page {packPage:string} renders its members in context
Then the page {specPage:string} renders the finding {findingId:string} as data
Then a second render from a freshly derived graph is byte-identical: {byteIdentical:boolean}
Then the render leaves the extraction root byte-identical: {rootUntouched:boolean}
```
